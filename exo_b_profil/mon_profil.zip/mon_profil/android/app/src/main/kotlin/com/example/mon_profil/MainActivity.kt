package com.example.mon_profil

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
